export function initializeBattlePage({ state, updateUI, persistProfile, showToast, saveState, getCreatureTemplates }) {

  const battleState = {
    yourFighter: null,
    oppFighter:  null,
    inBattle:    false,
    busy:        false,
    yourHp:      0,
    oppHp:       0,
  }

  // ── LAZY ELEMENT GETTER ───────────────────────────────────
  // All getElementById calls happen inside handlers/functions,
  // never at module load time, so missing elements can't crash init.
  const el = id => document.getElementById(id)

  // ── FIGHTER SELECT PANEL ──────────────────────────────────
  function renderSelectGrid() {
    const grid = el('fighter-select-grid')
    if (!grid) return

    if (!state.collection.length) {
      grid.innerHTML = '<div class="fighter-select-empty">No creatures yet — go roll some!</div>'
      return
    }

    grid.innerHTML = state.collection.map((c, i) => `
      <div class="fighter-pick-card rarity-${c.rarity}" data-idx="${i}">
        <div class="fighter-pick-sprite">${c.sprite || '?'}</div>
        <div class="fighter-pick-name">${c.nickname || c.name}</div>
        <div class="fighter-pick-level">Lv ${c.level}</div>
        <div class="fighter-pick-stats">ATK ${c.base_atk} · DEF ${c.base_def}</div>
      </div>
    `).join('')

    grid.querySelectorAll('.fighter-pick-card').forEach(card => {
      card.addEventListener('click', () => {
        const idx = parseInt(card.dataset.idx)
        confirmFighter(state.collection[idx])
      })
    })
  }

  // Exposed so app.js can call it when navigating to the battle tab
  window.refreshBattleSelectGrid = renderSelectGrid

  function confirmFighter(creature) {
    battleState.yourFighter = creature
    battleState.yourHp = creature.base_hp

    el('fighter-select-panel')?.classList.add('hidden')
    const youCard = el('fighter-you')
    if (youCard) {
      youCard.classList.remove('hidden')
      youCard.classList.remove('defeated')
    }

    el('you-sprite').textContent = creature.sprite || '?'
    el('you-name').textContent   = creature.nickname || creature.name
    setHpBar('you', battleState.yourHp, creature.base_hp)

    showToast(`${creature.name} is ready to fight!`)

    if (battleState.oppFighter && battleState.oppHp > 0) {
      battleState.inBattle = true
      el('btn-attack').disabled = false
    }
  }

  // ── WIRE UP HANDLERS (safe — only runs when element exists) ─
  function wireHandler(id, event, fn) {
    const node = el(id)
    if (node) node.addEventListener(event, fn)
  }

  // Swap button
  wireHandler('btn-swap-fighter', 'click', () => {
    if (battleState.inBattle) { showToast("Can't swap mid-battle!"); return }
    battleState.yourFighter = null
    el('fighter-you')?.classList.add('hidden')
    el('fighter-select-panel')?.classList.remove('hidden')
    el('btn-attack').disabled = true
    renderSelectGrid()
  })

  // Find opponent button
  wireHandler('btn-find-opponent', 'click', () => {
    const templates = getCreatureTemplates()
    if (!templates.length) { showToast('No opponents available — check DB seed.'); return }

    const template = templates[Math.floor(Math.random() * templates.length)]
    battleState.oppFighter = { ...template }
    battleState.oppHp = template.base_hp

    el('find-opponent-panel')?.classList.add('hidden')
    const oppCard = el('fighter-opp')
    if (oppCard) {
      oppCard.classList.remove('hidden')
      oppCard.classList.remove('defeated')
    }

    el('opp-sprite').textContent = template.sprite || '?'
    el('opp-name').textContent   = template.name
    setHpBar('opp', battleState.oppHp, template.base_hp)

    if (battleState.yourFighter && battleState.yourHp > 0) {
      battleState.inBattle = true
      el('btn-attack').disabled = false
      addLog(`A wild ${template.name} appeared! Battle begins!`, 'highlight')
    }
  })

  // Attack button
  wireHandler('btn-attack', 'click', async () => {
    if (!battleState.inBattle || battleState.busy) return
    battleState.busy = true
    el('btn-attack').disabled = true

    const you = battleState.yourFighter
    const opp = battleState.oppFighter

    const yourDmg = calcDmg(you.base_atk, opp.base_def)
    battleState.oppHp = Math.max(0, battleState.oppHp - yourDmg)
    addLog(`${you.name} attacks for ${yourDmg} damage!`, 'damage')
    setHpBar('opp', battleState.oppHp, opp.base_hp)

    if (battleState.oppHp <= 0) {
      await endBattle(true)
      return
    }

    setTimeout(async () => {
      const oppDmg = calcDmg(opp.base_atk, you.base_def)
      battleState.yourHp = Math.max(0, battleState.yourHp - oppDmg)
      addLog(`${opp.name} retaliates for ${oppDmg} damage!`, 'damage')
      setHpBar('you', battleState.yourHp, you.base_hp)

      if (battleState.yourHp <= 0) {
        await endBattle(false)
        return
      }

      battleState.busy = false
      el('btn-attack').disabled = false
    }, 650)
  })

  // ── END BATTLE ────────────────────────────────────────────
  async function endBattle(won) {
    battleState.inBattle = false
    battleState.busy = false
    el('btn-attack').disabled = true

    if (won) {
      addLog(`${battleState.yourFighter.name} wins! Victory! +50 gold`, 'win')
      state.wins++
      state.currency += 50
      el('fighter-opp')?.classList.add('defeated')
    } else {
      addLog(`${battleState.yourFighter.name} was defeated...`, 'win')
      el('fighter-you')?.classList.add('defeated')
    }

    await persistProfile()
    updateUI()
    saveState()

    setTimeout(() => {
      // Always reset opponent side → show Find Opponent panel again
      battleState.oppFighter = null
      battleState.oppHp = 0
      el('fighter-opp')?.classList.add('hidden')
      el('find-opponent-panel')?.classList.remove('hidden')

      // On loss reset your side too → show select panel again
      if (!won) {
        battleState.yourFighter = null
        battleState.yourHp = 0
        el('fighter-you')?.classList.add('hidden')
        el('fighter-select-panel')?.classList.remove('hidden')
        renderSelectGrid()
      }
    }, 2000)
  }

  // ── HELPERS ───────────────────────────────────────────────
  function calcDmg(atk, def) {
    return Math.max(1, Math.round(atk - def * 0.4 + (Math.random() * 10 - 5)))
  }

  function setHpBar(side, current, max) {
    const pct = Math.max(0, Math.round((current / max) * 100))
    const bar = el(`${side}-hp-bar`)
    const txt = el(`${side}-hp-text`)
    if (bar) { bar.style.width = `${pct}%`; bar.className = 'hp-bar' + (pct < 30 ? ' low' : '') }
    if (txt) txt.textContent = `${current} / ${max}`
  }

  function addLog(message, cls = '') {
    const log = el('battle-log')
    if (!log) return
    const line = document.createElement('div')
    line.className = `log-line ${cls}`.trim()
    line.textContent = message
    log.appendChild(line)
    log.scrollTop = log.scrollHeight
  }

  // ── INIT ─────────────────────────────────────────────────
  // Grid is rendered by app.js after bootstrap() finishes loading
  // the collection, and again whenever the battle tab is opened.
}